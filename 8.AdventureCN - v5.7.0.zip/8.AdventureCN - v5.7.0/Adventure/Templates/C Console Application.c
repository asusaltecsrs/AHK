﻿#include <stdio.h>
#include <conio.h>

int main() {
    printf("Hi!\n");
    getch();
    return 0;
}
